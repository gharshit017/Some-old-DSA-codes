#include <iostream>
using namespace std;
void reverse(int a){
    for(int i=0; i>=a.length; i++){
        
    }
}
int main(){
    int a;
    cout<<"Enter Number:";
    cin>>a;

    int reverse(a);

    return 0;
}