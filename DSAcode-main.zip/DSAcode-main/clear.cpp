#include<iostream>
#include<string>

using namespace std;

int main(){
    string abc ="hcaa ihaskdajoi iuhashasj ioju has";

    abc.clear();

    cout << abc <<endl;

    return 0;
}