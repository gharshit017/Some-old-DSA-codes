#include<iostream>
#include<string>

using namespace std;

int main(){
    string s1 = "not";

    s1.insert(2, "lol");
    cout<< s1 <<endl;
    return 0;
}
