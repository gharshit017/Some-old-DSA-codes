#include<iostream>
#include<string>

using namespace std;

int main(){
    int x = 786;

    cout<< to_string(x) + "2" <<endl;
    cout<< to_string(x+2) <<endl;
    
    return 0;
}