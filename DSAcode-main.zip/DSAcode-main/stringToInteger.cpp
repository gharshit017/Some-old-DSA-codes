#include<iostream>
#include<string>

using namespace std;

int main(){
    string s1 = "786";

    int x = stoi(s1);

    cout<< x+2 <<endl;
    
    return 0;
}